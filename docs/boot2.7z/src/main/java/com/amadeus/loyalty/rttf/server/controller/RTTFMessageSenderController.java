package com.amadeus.loyalty.rttf.server.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/rttf-server")
public class RTTFMessageSenderController {


	@Autowired
	private JmsTemplate jmsTemplate;

	@Value("${rttf.queue.name}")
	private String destination;

	@PostMapping("/message")
	public String send(@RequestBody String rttfMessage) {
		try {
			jmsTemplate.convertAndSend(destination, rttfMessage);
			return "OK";
		} catch (JmsException ex) {
			ex.printStackTrace();
			return "FAIL";
		}
	}
}